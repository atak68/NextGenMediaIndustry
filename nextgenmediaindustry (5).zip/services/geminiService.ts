import { GoogleGenAI, Type } from "@google/genai";

// Ensure API Key exists
const apiKey = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey });

export interface IdeaResponse {
  ideas: Array<{
    title: string;
    description: string;
    hashtag: string;
  }>;
}

export const generateContentIdeas = async (topic: string): Promise<IdeaResponse | null> => {
  if (!apiKey) {
    console.error("API Key not found");
    return null;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate 3 viral social media content ideas for a business regarding the topic: "${topic}". 
      Focus on modern, engaging, and trend-aware concepts.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            ideas: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING, description: "A catchy hook or title" },
                  description: { type: Type.STRING, description: "Brief explanation of the content concept" },
                  hashtag: { type: Type.STRING, description: "Primary trending hashtag" }
                }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) return null;
    
    return JSON.parse(text) as IdeaResponse;
  } catch (error) {
    console.error("Error generating ideas:", error);
    return null;
  }
};