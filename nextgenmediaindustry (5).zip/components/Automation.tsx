import React from 'react';
import { Cpu, PhoneForwarded, Workflow } from 'lucide-react';

const Automation: React.FC = () => {
  return (
    <section id="automation" className="py-24 bg-gradient-to-b from-[#0a0a0f] to-[#12121a] relative border-y border-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-neonPurple/40 text-neonPurple text-xs font-bold uppercase mb-6 tracking-widest">
              <Cpu size={14} /> KI-Revolution
            </div>
            <h2 className="font-heading text-4xl md:text-6xl font-bold text-white mb-8 leading-tight">
              Intelligente <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-neonPurple to-pink-500">
                Automatisierung
              </span>
            </h2>
            <p className="font-body text-xl text-gray-300 leading-relaxed mb-8">
              Wir implementieren intelligente KI-Automatisierungen — von Telefon-Systemen über Kundenservice bis hin zu internen Workflows.
              <br/><br/>
              Unsere Lösungen sparen Zeit, reduzieren Kosten und erhöhen Effizienz.
            </p>
            
            <div className="flex flex-col gap-4">
               <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10 hover:border-neonPurple/50 transition-colors">
                 <div className="p-3 bg-neonPurple/20 rounded-lg text-neonPurple"><PhoneForwarded /></div>
                 <div>
                   <h4 className="font-bold text-white">Smart Voice Agents</h4>
                   <p className="text-sm text-gray-400">24/7 telefonische Erreichbarkeit & Terminbuchung</p>
                 </div>
               </div>
               <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10 hover:border-neonPurple/50 transition-colors">
                 <div className="p-3 bg-neonPurple/20 rounded-lg text-neonPurple"><Workflow /></div>
                 <div>
                   <h4 className="font-bold text-white">Workflow Automation</h4>
                   <p className="text-sm text-gray-400">Nahtlose Integration zwischen Ihren Tools</p>
                 </div>
               </div>
            </div>
          </div>

          <div className="relative">
            {/* Abstract futuristic graphic representation */}
            <div className="relative w-full aspect-[4/3] bg-gray-900/50 rounded-2xl border border-gray-800 flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-neonPurple/10 via-transparent to-transparent opacity-50"></div>
                
                {/* Central Node */}
                <div className="relative z-10 w-24 h-24 bg-neonPurple rounded-full flex items-center justify-center shadow-[0_0_50px_#9d4dff] animate-pulse">
                   <Cpu className="text-white w-10 h-10" />
                </div>

                {/* Satellite Nodes */}
                <div className="absolute top-1/4 left-1/4 w-12 h-12 bg-gray-800 border border-neonBlue rounded-full flex items-center justify-center animate-bounce duration-[3000ms]">
                   <Bot size={20} className="text-neonBlue" />
                </div>
                <div className="absolute bottom-1/4 right-1/4 w-16 h-16 bg-gray-800 border border-pink-500 rounded-full flex items-center justify-center animate-bounce duration-[4000ms]">
                   <Share2 size={24} className="text-pink-500" />
                </div>
                
                {/* Connecting lines SVG */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30">
                  <line x1="50%" y1="50%" x2="25%" y2="25%" stroke="#9d4dff" strokeWidth="2" />
                  <line x1="50%" y1="50%" x2="75%" y2="75%" stroke="#9d4dff" strokeWidth="2" />
                </svg>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
import { Bot, Share2 } from 'lucide-react'; // Added import for icons used in graphic
export default Automation;