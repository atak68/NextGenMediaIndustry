import React from 'react';
import { Share2, Globe, Bot, PenTool, Layers } from 'lucide-react';

const ServiceCard: React.FC<{ title: string; icon: React.ReactNode }> = ({ title, icon }) => (
  <div className="group relative p-8 rounded-2xl bg-[#0f0f16] border border-gray-800 hover:border-neonBlue/50 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(0,234,255,0.15)] overflow-hidden">
    <div className="absolute inset-0 bg-gradient-to-br from-neonBlue/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
    <div className="relative z-10 flex flex-col items-center text-center">
      <div className="mb-6 p-4 rounded-full bg-gray-900 text-neonBlue group-hover:bg-neonBlue group-hover:text-background transition-colors duration-300 shadow-lg">
        {icon}
      </div>
      <h3 className="font-heading text-xl font-bold text-white mb-2 group-hover:text-neonBlue transition-colors">
        {title}
      </h3>
      <div className="w-12 h-1 bg-gray-700 rounded-full group-hover:w-24 group-hover:bg-neonPurple transition-all duration-300 mt-4"></div>
    </div>
  </div>
);

const Services: React.FC = () => {
  const services = [
    { title: "Social Media Management", icon: <Share2 size={32} /> },
    { title: "Website-Erstellung", icon: <Globe size={32} /> },
    { title: "KI-Automatisierung", icon: <Bot size={32} /> },
    { title: "Content-Produktion", icon: <PenTool size={32} /> },
    { title: "Brand Identity & Creative Direction", icon: <Layers size={32} /> },
  ];

  return (
    <section id="services" className="py-24 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-neonPurple/5 skew-x-12 blur-3xl -z-10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">
            Unsere <span className="text-neonBlue">Services</span>
          </h2>
          <p className="font-body text-gray-400 max-w-2xl mx-auto text-lg">
            Ganzheitliche Lösungen für Ihr digitales Wachstum.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard key={index} title={service.title} icon={service.icon} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;