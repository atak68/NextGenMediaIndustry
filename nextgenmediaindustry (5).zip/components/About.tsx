import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-background relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Visual Side */}
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden relative z-10 border border-gray-700/50">
               <img src="https://picsum.photos/800/800?grayscale" alt="Team working" className="w-full h-full object-cover opacity-80 hover:scale-105 transition-transform duration-700" />
               <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
            </div>
            {/* Decoration */}
            <div className="absolute -top-4 -left-4 w-full h-full border border-neonBlue/30 rounded-2xl -z-0"></div>
            <div className="absolute -bottom-4 -right-4 w-full h-full border border-neonPurple/30 rounded-2xl -z-0"></div>
          </div>

          {/* Text Side */}
          <div>
            <h2 className="font-heading text-4xl md:text-5xl font-bold mb-8">
              <span className="text-neonBlue">NextGen</span>MediaIndustry
            </h2>
            
            <div className="space-y-6 font-body text-lg text-gray-300 leading-relaxed bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-md">
              <p>
                Wir sind NextGenMediaIndustry — eine zukunftsorientierte Digitalagentur, gegründet mit dem Ziel, kleinen und wachsenden Unternehmen ein modernes, professionelles Auftreten zu geben.
              </p>
              <p>
                Wir helfen Firmen, mehr Kunden zu gewinnen, ihre Prozesse zu automatisieren und in die digitale Zukunft einzusteigen.
              </p>
              <div className="pt-4 border-l-4 border-neonPurple pl-4 mt-4">
                <h3 className="text-xl font-bold text-white mb-2 font-heading">Unser langfristiges Ziel:</h3>
                <p>
                  Zu einer der führenden Agenturen für Digitalisierung, KI-Automatisierung und Social Media Marketing in Europa zu werden.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;