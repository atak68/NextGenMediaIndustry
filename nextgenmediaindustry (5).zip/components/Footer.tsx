import React, { useState } from 'react';

const Footer: React.FC = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <footer className="py-12 bg-black border-t border-gray-900 text-center relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-96 h-32 bg-neonBlue/5 blur-[50px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 flex flex-col items-center justify-center">
        
        {/* Footer Logo */}
        <div className="mb-6 relative group cursor-default">
           <div className="w-[60px] h-[60px] rounded-full bg-black border border-neonBlue/30 shadow-[0_0_10px_rgba(0,234,255,0.3)] group-hover:shadow-[0_0_20px_rgba(0,234,255,0.6)] transition-all duration-500 overflow-hidden flex items-center justify-center">
             {!imgError ? (
                <img 
                  src="A_logo_for_NextGenMediaIndustry_features_a_futuris.png" 
                  alt="NextGenMediaIndustry Logo" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                  onError={() => setImgError(true)}
                />
             ) : (
                <svg viewBox="0 0 100 100" className="w-full h-full p-3 opacity-70 group-hover:opacity-100 transition-opacity">
                   <defs>
                     <linearGradient id="footerLogoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                       <stop offset="0%" stopColor="#00eaff" />
                       <stop offset="100%" stopColor="#9d4dff" />
                     </linearGradient>
                   </defs>
                   <path 
                     d="M25 20 L25 80 L75 20 L75 80" 
                     stroke="url(#footerLogoGrad)" 
                     strokeWidth="8" 
                     strokeLinecap="round" 
                     strokeLinejoin="round" 
                     fill="none" 
                   />
                </svg>
             )}
           </div>
        </div>

        <p className="font-body text-gray-500 text-sm">
          © 2025 NextGenMediaIndustry – Zukunft beginnt heute.
        </p>
      </div>
    </footer>
  );
};

export default Footer;