import React from 'react';
import { Mail, Instagram } from 'lucide-react';

// Custom TikTok icon since Lucide might not have it or it's similar to music
const TikTokIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="lucide lucide-music"
  >
    <path d="M9 18V5l12-2v13" />
    <circle cx="6" cy="18" r="3" />
    <circle cx="18" cy="16" r="3" />
  </svg>
);

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 bg-background border-t border-gray-900">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <h2 className="font-heading text-4xl font-bold text-white mb-12">Kontakt</h2>
        
        <div className="flex flex-col md:flex-row justify-center gap-8 md:gap-16">
          <a href="mailto:nextgenmediagermany@gmail.com" className="flex flex-col items-center group">
            <div className="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center text-neonBlue mb-4 group-hover:scale-110 group-hover:bg-neonBlue group-hover:text-background transition-all duration-300">
              <Mail size={32} />
            </div>
            <span className="text-gray-300 group-hover:text-neonBlue transition-colors">nextgenmediagermany@gmail.com</span>
          </a>

          <a href="https://instagram.com/nextgenmediaindustry" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center group">
             <div className="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center text-pink-500 mb-4 group-hover:scale-110 group-hover:bg-pink-500 group-hover:text-white transition-all duration-300">
              <Instagram size={32} />
            </div>
            <span className="text-gray-300 group-hover:text-pink-500 transition-colors">@nextgenmediaindustry</span>
          </a>

          <a href="https://tiktok.com/@nextgenmediaindustry" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center group">
             <div className="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center text-white mb-4 group-hover:scale-110 group-hover:bg-white group-hover:text-black transition-all duration-300">
              <TikTokIcon />
            </div>
            <span className="text-gray-300 group-hover:text-white transition-colors">@nextgenmediaindustry</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Contact;