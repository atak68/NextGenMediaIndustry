import React from 'react';
import { ArrowRight, ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {

  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-96 h-96 bg-neonBlue/20 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-neonPurple/20 rounded-full blur-[120px] translate-x-1/2 translate-y-1/2"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
        <div className="mb-6 inline-block px-4 py-1 rounded-full border border-neonBlue/30 bg-neonBlue/10 backdrop-blur-sm">
            <span className="text-neonBlue text-sm font-bold tracking-widest uppercase">Willkommen in der Zukunft</span>
        </div>
        
        <h1 className="font-heading font-black text-5xl md:text-7xl lg:text-8xl leading-tight mb-6">
          <span className="block text-white">Wir digitalisieren &</span>
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-neonBlue to-neonPurple neon-text-glow">
            automatisieren
          </span>
          <span className="block text-white text-3xl md:text-5xl mt-2">die Zukunft Ihres Unternehmens.</span>
        </h1>

        <p className="font-body text-gray-400 text-xl md:text-2xl mb-10 max-w-3xl mx-auto leading-relaxed">
          NextGenMediaIndustry — KI-gestützte Social Media, Websites & Automatisierungen, die Ergebnisse liefern.
        </p>

        <div className="flex flex-col md:flex-row items-center justify-center gap-6">
          <a 
            href="#request" 
            onClick={(e) => handleScroll(e, '#request')}
            className="group relative px-8 py-4 bg-neonBlue text-background font-bold text-lg rounded-none skew-x-[-10deg] hover:bg-white transition-colors duration-300 cursor-pointer"
          >
            <span className="block skew-x-[10deg] flex items-center gap-2">
              Jetzt anfragen <ArrowRight className="group-hover:translate-x-1 transition-transform" />
            </span>
            <div className="absolute inset-0 border border-white opacity-0 group-hover:opacity-100 group-hover:scale-105 transition-all duration-300 skew-x-[-10deg]"></div>
          </a>
          
          <a 
            href="#services" 
            onClick={(e) => handleScroll(e, '#services')}
            className="group px-8 py-4 border border-neonPurple text-neonPurple font-bold text-lg rounded-none skew-x-[-10deg] hover:bg-neonPurple hover:text-white transition-all duration-300 cursor-pointer"
          >
            <span className="block skew-x-[10deg]">Unsere Services</span>
          </a>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-gray-500">
        <ChevronDown size={32} />
      </div>
    </section>
  );
};

export default Hero;