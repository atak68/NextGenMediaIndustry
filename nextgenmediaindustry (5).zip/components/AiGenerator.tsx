import React, { useState } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';
import { generateContentIdeas, IdeaResponse } from '../services/geminiService';

const AiGenerator: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<IdeaResponse | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setLoading(true);
    setResult(null);
    
    try {
      const data = await generateContentIdeas(topic);
      setResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="generator" className="py-24 bg-[#050508] relative overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-neonBlue/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">
            AI-Instant-Ideen <span className="text-neonBlue">Generator</span>
          </h2>
          <p className="text-gray-400">Nutze die Kraft unserer KI für deinen nächsten viralen Hit.</p>
        </div>

        <div className="bg-gray-900/50 backdrop-blur-md border border-gray-700 p-8 rounded-3xl shadow-2xl">
          <form onSubmit={handleGenerate} className="flex flex-col md:flex-row gap-4 mb-8">
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Thema eingeben (z.B. 'Vegan kochen', 'Krypto', 'Handwerk')..."
              className="flex-1 bg-gray-800 text-white px-6 py-4 rounded-xl border border-gray-700 focus:border-neonBlue focus:ring-1 focus:ring-neonBlue outline-none transition-all placeholder-gray-500"
            />
            <button
              type="submit"
              disabled={loading || !topic}
              className="px-8 py-4 bg-gradient-to-r from-neonBlue to-cyan-600 text-background font-bold rounded-xl hover:shadow-[0_0_20px_rgba(0,234,255,0.4)] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="animate-spin" /> : <Sparkles />}
              Ideen generieren
            </button>
          </form>

          {result && (
            <div className="grid gap-6">
              {result.ideas.map((idea, idx) => (
                <div key={idx} className="p-6 rounded-xl border border-neonPurple/30 bg-neonPurple/5 hover:bg-neonPurple/10 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-heading text-xl font-bold text-white">{idea.title}</h3>
                    <span className="text-xs bg-neonPurple text-white px-2 py-1 rounded">#{idx + 1}</span>
                  </div>
                  <p className="text-gray-300 text-sm mb-3">{idea.description}</p>
                  <span className="text-neonBlue text-sm font-mono">{idea.hashtag}</span>
                </div>
              ))}
            </div>
          )}
          
          {!result && !loading && (
            <div className="text-center text-gray-600 py-8">
              Gib ein Thema ein, um sofort Content-Vorschläge zu erhalten.
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default AiGenerator;