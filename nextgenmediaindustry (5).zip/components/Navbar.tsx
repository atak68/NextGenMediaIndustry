import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Start', href: '#hero' },
    { name: 'Über uns', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Automatisierung', href: '#automation' },
    { name: 'AI-Ideen', href: '#generator' },
    { name: 'Kontakt', href: '#contact' },
    { name: 'Anfrage', href: '#request' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    
    if (element) {
      // 80px offset for the fixed navbar
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-background/90 backdrop-blur-lg border-b border-neonBlue/20 py-2' : 'bg-transparent py-4'}`}>
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo Section - Links to #hero */}
          <a 
            href="#hero" 
            onClick={(e) => handleNavClick(e, '#hero')}
            className="flex-shrink-0 flex items-center gap-3 group/logo cursor-pointer" 
            aria-label="Zurück zum Start"
          >
             <div className="relative w-[60px] h-[60px] flex-shrink-0">
                {/* Fallback SVG / Image Container */}
                <div className="absolute inset-0 rounded-full bg-black border-2 border-neonBlue shadow-[0_0_15px_rgba(0,234,255,0.5)] overflow-hidden flex items-center justify-center group-hover/logo:shadow-[0_0_25px_rgba(0,234,255,0.8)] transition-all duration-300">
                  {/* Try to load image, if fails, show SVG */}
                  {!imgError ? (
                    <img 
                      src="A_logo_for_NextGenMediaIndustry_features_a_futuris.png" 
                      alt="NextGen Logo" 
                      className="w-full h-full object-cover"
                      onError={() => setImgError(true)}
                    />
                  ) : (
                    <svg viewBox="0 0 100 100" className="w-full h-full p-2">
                       <defs>
                         <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                           <stop offset="0%" stopColor="#00eaff" />
                           <stop offset="100%" stopColor="#9d4dff" />
                         </linearGradient>
                         <filter id="glow">
                           <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
                           <feMerge>
                             <feMergeNode in="coloredBlur"/>
                             <feMergeNode in="SourceGraphic"/>
                           </feMerge>
                         </filter>
                       </defs>
                       <path 
                         d="M25 20 L25 80 L75 20 L75 80" 
                         stroke="url(#logoGradient)" 
                         strokeWidth="8" 
                         strokeLinecap="round" 
                         strokeLinejoin="round" 
                         fill="none" 
                         filter="url(#glow)"
                       />
                    </svg>
                  )}
                </div>
             </div>
             <span className="hidden md:block font-heading font-bold text-xl tracking-wider text-white">
               NEXTGEN<span className="text-neonBlue">MEDIA</span>
             </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6 xl:space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="font-body font-medium text-gray-300 hover:text-neonBlue hover:drop-shadow-[0_0_5px_rgba(0,234,255,0.8)] transition-all duration-200 text-base xl:text-lg cursor-pointer whitespace-nowrap"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-300 hover:text-neonBlue focus:outline-none"
              aria-label="Menü öffnen"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-background/95 backdrop-blur-xl border-t border-gray-800 absolute top-full left-0 w-full h-screen overflow-y-auto pb-20">
          <div className="px-4 pt-4 pb-3 space-y-4 sm:px-3 flex flex-col items-center justify-center min-h-[50vh]">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="block px-3 py-2 text-2xl font-heading font-bold text-gray-300 hover:text-neonBlue transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;