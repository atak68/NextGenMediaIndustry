import React, { useState } from 'react';
import { Send } from 'lucide-react';

const RequestForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Logic to send email would go here (e.g., connect to EmailJS or backend)
    alert('Vielen Dank für Ihre Anfrage! Wir melden uns in Kürze.');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <section id="request" className="py-24 relative">
       <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] opacity-10"></div>
       <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>

      <div className="max-w-2xl mx-auto px-4 relative z-10">
        <div className="bg-gray-900/40 backdrop-blur-xl border border-white/10 p-8 md:p-12 rounded-3xl shadow-[0_0_40px_rgba(0,234,255,0.05)] neon-box-glow">
          <h2 className="font-heading text-3xl font-bold text-center text-white mb-8">
            Starten Sie Ihre <span className="text-neonBlue">Transformation</span>
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-2">Name</label>
              <input
                type="text"
                id="name"
                required
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full bg-black/50 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-neonBlue focus:ring-1 focus:ring-neonBlue outline-none transition-all"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-2">Email</label>
              <input
                type="email"
                id="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full bg-black/50 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-neonBlue focus:ring-1 focus:ring-neonBlue outline-none transition-all"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-400 mb-2">Nachricht</label>
              <textarea
                id="message"
                required
                rows={4}
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                className="w-full bg-black/50 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-neonBlue focus:ring-1 focus:ring-neonBlue outline-none transition-all resize-none"
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-neonBlue text-background font-bold text-lg rounded-lg hover:bg-white transition-colors duration-300 flex items-center justify-center gap-2"
            >
              Anfrage senden <Send size={20} />
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default RequestForm;